# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/LL_after_hidden_level_reestimation_NOcov.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/Viterbi.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/hmtd_mu_NOcov.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/hmtd_sigma_nocov.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/forward_procedure_NOcov.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/hmtd_sigma_nocov.R")
# source("C:/Users/ztau/switchdrive/R package HMTD all versions/Package 5 - HMTDvartimeint LAST Mstep try1/HMTD - last updated version to compile all packages/R/forward_procedure_NOcov.R")
# X_cov=0


EMalgorithm<-function(completedata, n,seqlengths,r,k,OHC,kOHC,Pi,A,RA,Phi, P,maxP,Theta,Q,picov=NA, timeintervals=0, X_cov=0,it=100000,...){
  # picov=NA; timeintervals=array(1,c(1,ncol(completedata))); X_cov=0
  envir=new.env()
  if(timeintervals==0){timeintervals=array(1:ncol(completedata))}
  ###################################################
  #######  Mstep: choice of dervative function ######
  if(r==0){                   # if the mean is CONSTANT:
    Mstep<-function(Phi,Theta, Vit,r,k,completedata){
      TT=ncol(completedata)
      for(g in 1:k){
        X=completedata[which(Vit==g),]
        Xt=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          Xt=X[,t]         +Xt1
        }
        # Phi[g,1]= mean(  Xt/ TT-r  ) #Phi0 (= Phi[g,1] )
        Phi[g,1]= median(  Xt/ TT-r  ) #Phi0 (= Phi[g,1] )
        Xmu=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          Xmu = (X[,t] - Phi[g,1])^2   +Xmu #sum of all squared distances
        }
        # Theta[g,1] = mean( Xmu / (TT-r)  )  # Theta
        Theta[g,1] = median( Xmu / (TT-r)  )  # Theta

      }
      retunrn = list(Phi, Theta)
    }
  } else if(r==1){                  # if the mean has 1 LAG:
    Mstep<-function(Phi,Theta, Vit,r,k,completedata){
      TT=ncol(completedata)
      for(g in 1:k){
        X=completedata[which(Vit==g),]
        XtXt1=array(0,c(nrow(X),1))
        Xt1_2=array(0.0001,c(nrow(X),1))
        Xt1=array(0,c(nrow(X),1))
        Xt=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          XtXt1=X[,t]*X[,t-1] +XtXt1
          Xt1_2=(X[,t-1])^2   +Xt1_2
          Xt1=X[,t-1]         +Xt1
          Xt=X[,t]            +Xt
        }
        #Phi[g,1]= mean(  (Xt - Phi[g,2]*Xt1)/(TT-r)  ) #Phi0 (= Phi[g,1] )
        Phi[g,1]= median(  (Xt - Phi[g,2]*Xt1)/(TT-r)  ) #Phi0 (= Phi[g,1] )
        #Phi[g,2]= mean( (XtXt1 - Phi[g,1]*Xt1) / Xt1_2  ) #Phi1 (= Phi[g,2] )
        Phi[g,2]= median( (XtXt1 - Phi[g,1]*Xt1) / Xt1_2  ) #Phi1 (= Phi[g,2] )
        # lm(XtXt1~Phi[g,2]*Xgt)
        Xmu=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          Xmu = (X[,t] - (Phi[g,1] + Phi[g,2]*X[,t-1]))^2   +Xmu #sum of all squared distances
        }
        #Theta[g,1] = mean( Xmu / (TT-r)  )  # Theta
        Theta[g,1] = median( Xmu / (TT-r)  )  # Theta

      }
      retunrn = list(Phi, Theta)
    }
  } else if(r==2){          # if the mean has 2 LAGS:
    Mstep<-function(Phi,Theta, Vit,r,k,completedata){
      TT=ncol(completedata)
      for(g in 1:k){
        X=completedata[which(Vit==g),]
        Xt=array(0,c(nrow(X),1))
        Xt1=array(0,c(nrow(X),1))
        XtXt1=array(0,c(nrow(X),1))
        XtXt2=array(0,c(nrow(X),1))
        Xt2=array(0,c(nrow(X),1))
        Xt2_2=array(0.0001,c(nrow(X),1))
        Xt1_2=array(0.0001,c(nrow(X),1))
        Xt1Xt2=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          Xt= X[,t]                 +Xt
          Xt1= X[,t-1]              +Xt1
          Xt2= X[,t-2]              +Xt2
          XtXt1=X[,t]*X[,t-1]       +XtXt1
          XtXt2=X[,t]*X[,t-2]       +XtXt2
          Xt1Xt2= X[,t-1]*X[,t-2]   +Xt1Xt2
          Xt1_2= X[,t-1]^2          +Xt1_2
          Xt2_2= X[,t-2]^2          +Xt2_2
        }

        # Phi[g,1]= mean(  (Xt - Phi[g,2]*Xt1  - Phi[g,3]*Xt2)/(TT-r)  ) #Phi0 (= Phi[g,1] )
        # Phi[g,2]=  mean(  (XtXt1 - Phi[g,1]*Xt1    - Phi[g,3]*Xt1Xt2) / Xt1_2  ) #Phi1 (= Phi[g,2] )
        # Phi[g,3]= mean(  (XtXt2 - Phi[g,1]*Xt2    - Phi[g,2]*Xt1Xt2) / Xt2_2  ) #Phi1 (= Phi[g,3] )
        Phi[g,1]= median(  (Xt - Phi[g,2]*Xt1  - Phi[g,3]*Xt2)/(TT-r)  ) #Phi0 (= Phi[g,1] )
        Phi[g,2]=  median(  (XtXt1 - Phi[g,1]*Xt1    - Phi[g,3]*Xt1Xt2) / Xt1_2  ) #Phi1 (= Phi[g,2] )
        Phi[g,3]= median(  (XtXt2 - Phi[g,1]*Xt2    - Phi[g,2]*Xt1Xt2) / Xt2_2  ) #Phi1 (= Phi[g,3] )
        Xmu=array(0,c(nrow(X),1))
        for(t in (r+1):TT){
          Xmu = (X[,t] - (Phi[g,1] + Phi[g,2]*X[,t-1] + Phi[g,3]*X[,t-2]))^2   +Xmu #sum of all squared distances
        }
        # Theta[g,1] = mean( Xmu / (TT-r)  )  # Theta
        Theta[g,1] = median( Xmu / (TT-r)  )  # Theta
      }
      retunrn = list(Phi, Theta)
    }
  } else print("The mean has too many lags. Is that necessary? If it is, use procedure=PSO.")



  ############## EM algorithm ######################

  #it = 10
  maxLL=-1e+09
  bestsolparamsThetaPhi<<-cbind(Theta*0,Phi*0)
  bestsolclusters=array(0,c(1,nrow(completedata)))
  #LL_iteration = array(0, dim=c(1,it))
  #GENERATE SEVERAL RANDOM CLUSTERS FOR INITIAL VALUES
  randstart=0
  rows=nrow(completedata)

  while (randstart<it){
    randstart=randstart+1
    #print(randstart)

    #initiate Vit, Phi and Theta!
    Vit=sample(1:k,rows,prob=c(runif(k, min = 0.05, max = 1)), replace=TRUE)

    Phi=array(c(runif(k,min=min(completedata), max=max(0.5*max(completedata),mean(completedata))),runif(k*r,min=0.01,max=0.6)),  c(k,(r+1)))
    Theta=matrix( runif(k,min=sd(completedata)*0.2, max=sd(completedata)) , c(k,1))#sd(completedata)
    #print(cbind(Phi,Theta)); print("NEW!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")

    Phiold=Phi*0
    starts=0
    tV=table(Vit)
    tVprevious=table(Vit)+1
    tVprevious2=table(Vit)+2
    tVprevious3=table(Vit)+3



    while (length(table(Vit))==k  &  all(tVprevious3!=array(table(Vit),c(k))) & all(table(Vit)!=1) ){
      # Only execute when: there are no empty clusters, the clusters haven't change for 3 iterations, no cluster has one single observation!
      starts=starts+1#starts<50 &
      #print("New iteration");print(tVprevious); print(table(Vit));

      tVprevious3=tVprevious2
      tVprevious2=tVprevious
      tVprevious=table(Vit)


      while(!all(round(Phi,2)==round(Phiold,2))){
        Phiold=Phi
        #######################
        ### Compute the M-step:
        outt<-Mstep(Phi,Theta, Vit=Vit, r, k, completedata)
        Phi=outt[[1]]; Theta=outt[[2]]
      }
      Phiold=Phi*0


      #######################
      ### Compute the E-step:
      output=LL_after_hidden_level_reestimation_NOcov(Data=completedata, n,seqlengths,r,k,OHC,kOHC,Pi,A,RA,Phi  ,P,maxP,Theta,Q,maxQ=maxQ,spec=0,picov=NA,Pi_withCovariates, timeintervals=timeintervals, X_cov=0)
      LL= output[[1]]; #trueLL=output[[7]]
      A=output[[2]]
      Pi=output[[3]]
      Vit=output[[4]]

      #print(LL); print(table(Vit)); print(Phi); print(Theta)
      if(length(table(Vit))==k){
        maxLL=max(LL,maxLL)
        if(LL==maxLL){bestsolparamsThetaPhi=cbind(Theta,Phi); bestsolclusters=Vit; bestLL=maxLL; print("Likelihood improved")}
      }
      tV=table(Vit)
    }
  }

  return=list(maxLL, bestsolparamsThetaPhi, bestsolclusters)
}

