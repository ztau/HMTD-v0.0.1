#' Mean estimation
#'
#' Calculates the mean withOUT visible level covariates
#'
#' @param Data Dataset
#' @param Phi Auto-regressive parameters for the mean
#' @param timeintervals1 the intervals between time( ex: c(0,1,2,4,5,6))
#' @param ... Optional operational parameters (not needed)
#' @return mu
#' @export


hmtd_mu_NOcov<-function(Phi,Data,timeintervals1=1,...){

    # Phi: (1 x p+1): phi(g,0) to phi(g,p) coeficients
    # Data: (p x 1): observations from t-p to t-1                       !!!
    # p: number of lags to compute the expectation for the mean
    # mu: expectation of component g at time t

    # timneintervals: scalar (proportion of intervals from the previous period) (ATTENTION: works only for p=1 !)


    #P=length(Data)
    #mu=Phi[1]

    #for(i in 1:p){3
    #  mu=mu+Phi(i+1)*Data(p-i+1)  # -> Data x Phi
    # }

    mu=Phi[1]+if(length(Phi)>1){(Phi[2:(length(Data)+1)])^timeintervals1%*%t(t(rev(Data)))}else{0}

    return(mu)
}
